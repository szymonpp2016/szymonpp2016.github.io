$( document ).ready(function() {
    $("#my_custom_button").click(function() {
       $("#my_custom_div").toggle();
    });
});